liberta_anti_cheat_config = {}


liberta_avl_fuck = true -- true is conseiller, vraiment, pour la survie de votre serveur (false pour desactiver)



liberta_anti_cheat_config.discord_webhook = "https://discord.com/api/webhooks"
liberta_anti_cheat_config.hashKey = "" 

liberta_anti_cheat_config.lib_log_discord = true 
liberta_anti_cheat_config.lib_whatshouldLog = {["kicked"] = true, ["banned"] = true, ["verified"] = true} 


liberta_anti_cheat_config.stealib_api_key = "" 

liberta_anti_cheat_config.kick_banned_family_shared = true 
liberta_anti_cheat_config.kick_all_family_shared = false

liberta_anti_cheat_config.lib_log_console = true 
liberta_anti_cheat_config.lib_log_file = true 


liberta_anti_cheat_config.lib_use_custolib_ban_reason = true 
liberta_anti_cheat_config.lib_ban_reason = "[Liberta Anti Cheat] Invalid lua executed"

liberta_anti_cheat_config.developermode = false 

liberta_anti_cheat_config.lib_validate_players = true -
liberta_anti_cheat_config.lib_check_file = true 
liberta_anti_cheat_config.lib_check_function = true 
liberta_anti_cheat_config.lib_check_globals = true 
liberta_anti_cheat_config.lib_check_modules = true 
liberta_anti_cheat_config.lib_check_cvars = true 
liberta_anti_cheat_config.lib_check_synced_cvars = true
liberta_anti_cheat_config.lib_check_external = true 
liberta_anti_cheat_config.lib_check_dhtml = true
liberta_anti_cheat_config.lib_check_cleaning_screen = true 
liberta_anti_cheat_config.lib_check_detoured_functions = true
liberta_anti_cheat_config.lib_simulate_backdoors = true 
liberta_anti_cheat_config.lib_backup_kick_check = true 
liberta_anti_cheat_config.lib_check_concommands = true 
liberta_anti_cheat_config.lib_fuck_aimbot = true