--[[																												Regarde en bas à gauche	
                                          Regarde en haut à droite  	
																																	


																																											



																																					





















																												j'ai dit gauche clochard




gentille toutou																																														
--]]